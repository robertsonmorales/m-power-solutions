-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 05:02 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mpowersolutions`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail_logs`
--

CREATE TABLE `audit_trail_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Global Financial Markets and Instruments', '2022-06-09 02:43:58', '2022-06-09 02:43:58'),
(2, 'Data Science', '2022-06-09 02:43:58', '2022-06-09 02:43:58'),
(3, 'Public Health', '2022-06-09 02:43:58', '2022-06-09 02:43:58'),
(4, 'Management', '2022-06-09 02:43:58', '2022-06-09 02:43:58'),
(5, 'Data Analytics', '2022-06-09 02:43:58', '2022-06-09 02:43:58'),
(6, 'Online MBA and Business', '2022-06-09 02:43:58', '2022-06-09 02:43:58');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2020_09_24_142209_create_audit_trail_logs_table', 1),
(6, '2021_02_25_021507_create_navigations_table', 1),
(7, '2021_02_27_194712_create_user_levels_table', 1),
(8, '2021_10_26_140557_create_table_management_table', 1),
(9, '2021_11_03_225804_create_user_browser_sessions_table', 1),
(10, '2022_06_08_004616_create_statuses_table', 1),
(11, '2022_06_08_174000_create_students_table', 1),
(12, '2022_06_08_191903_create_courses_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `navigations`
--

CREATE TABLE `navigations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nav_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nav_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nav_route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nav_controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nav_icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nav_order` int(11) DEFAULT NULL,
  `nav_suborder` int(11) DEFAULT NULL,
  `nav_childs_parent_id` int(11) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `navigations`
--

INSERT INTO `navigations` (`id`, `nav_type`, `nav_name`, `nav_route`, `nav_controller`, `nav_icon`, `nav_order`, `nav_suborder`, `nav_childs_parent_id`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'single', 'Knowledge Base', 'dashboard', 'Dashboard', 'dashboard', 1, NULL, NULL, '1', NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(2, 'single', 'Book', 'books', 'Dashboard', 'book', 2, NULL, NULL, '1', NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(3, 'single', 'Students', 'students', 'Student', 'student', 3, NULL, NULL, '1', NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(4, 'single', 'Calendar', 'calendar', 'Dashboard', 'calendar', 4, NULL, NULL, '1', NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(5, 'single', 'Message', 'messages', 'Dashboard', 'messages-2', 5, NULL, NULL, '1', NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bg_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `color`, `bg_color`, `created_at`, `updated_at`) VALUES
(1, 'Active', '#18AB56', '#F0FFF8', '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(2, 'Pending', '#FFBC10', '#FEFFE6', '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(3, 'Drop Out', '#EB5757', '#FFF0F0', '2022-06-09 02:43:58', '2022-06-09 02:43:58');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `full_name`, `email`, `contact`, `region`, `course_id`, `section`, `status_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Mr. Manley Daugherty MD', 'reynolds.keegan@yahoo.com', '09123456789', '18711 Kozey Manors Apt. 625\nHirtheborough, WV 85337-1842', NULL, '6', 2, NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(2, 'Evie Lubowitz', 'faustino.ritchie@yahoo.com', '09123456789', '881 Everett Key Apt. 828\nLake Sibyl, DC 49926-3554', NULL, '5', 3, NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(3, 'Elenora Monahan', 'kirk76@gmail.com', '09123456789', '212 Marquardt Viaduct\nNew Salmafurt, WI 92905-4937', NULL, '6', 3, NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(4, 'Noble Kassulke V', 'pveum@buckridge.biz', '09123456789', '662 Salvador Row Apt. 208\nMcCulloughstad, OH 25975-6923', NULL, '2', 1, NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55'),
(5, 'Monserrate Keebler', 'jschowalter@hotmail.com', '09123456789', '4945 Laura Walk\nLake Dagmarshire, ME 84171', NULL, '10', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(6, 'Mr. Sammy Bernier I', 'doreilly@price.org', '09123456789', '54043 Ritchie Summit\nLake Mariliechester, WI 91755', NULL, '3', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(7, 'Katelynn Emard', 'wdeckow@yahoo.com', '09123456789', '289 Adelle Landing\nPort Jessyburgh, OK 83191-3391', NULL, '1', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(8, 'Jamir Ward I', 'zquigley@yahoo.com', '09123456789', '4856 Douglas Mill Suite 774\nPort Stewart, TN 51108-9832', NULL, '6', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(9, 'Mr. Kim Swaniawski', 'vicky.towne@torphy.com', '09123456789', '28241 Colton Place Suite 920\nJordanton, FL 10999-2052', NULL, '3', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(10, 'Dandre Dietrich', 'rice.archibald@hotmail.com', '09123456789', '40691 Anika Crossing Suite 363\nTayashire, AK 84810-3099', NULL, '9', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(11, 'Dr. Mervin Abbott MD', 'estanton@gmail.com', '09123456789', '95106 Deangelo Road Suite 285\nNikolausshire, GA 11450', NULL, '10', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(12, 'Mafalda Kulas I', 'okris@nolan.com', '09123456789', '475 Bashirian Pine Suite 117\nNorth Violetteshire, CA 06523', NULL, '3', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(13, 'Miss Althea Borer', 'elliot88@yahoo.com', '09123456789', '383 Tito Stream\nHahnland, NC 33584', NULL, '4', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(14, 'Gilbert Harris', 'kling.dangelo@yahoo.com', '09123456789', '829 Juliet Plains Suite 240\nWest Mckaylaburgh, OR 65354', NULL, '8', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(15, 'Clint Ondricka', 'rdare@bins.net', '09123456789', '168 Gislason Port\nEast Nellamouth, MI 58029', NULL, '5', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(16, 'Lacy Gislason', 'wisozk.melvina@hackett.biz', '09123456789', '3966 Orn Brooks\nKrajcikfurt, WA 41999-1440', NULL, '3', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(17, 'Rosie Frami', 'hadley76@hotmail.com', '09123456789', '5745 Rippin Key Apt. 501\nGerholdtown, CT 15568-5856', NULL, '3', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(18, 'Raina Jacobs', 'reinger.amos@gmail.com', '09123456789', '61017 Katheryn Trail\nTitoport, AR 54648', NULL, '7', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(19, 'Rasheed Predovic MD', 'ubeer@yahoo.com', '09123456789', '931 Nicolas Row\nMcKenzieview, MO 35510', NULL, '9', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(20, 'Mrs. Jana Zulauf', 'fjerde@hotmail.com', '09123456789', '442 Ullrich Groves Suite 969\nJaskolskiton, WV 08989', NULL, '10', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(21, 'Mrs. Tatyana Franecki III', 'derek.lindgren@hotmail.com', '09123456789', '85540 Santina Parkways\nCormierton, MA 03103', NULL, '6', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(22, 'Neal Grimes', 'dschinner@hotmail.com', '09123456789', '7879 Megane Point Suite 994\nNew Flavie, WV 35592-8125', NULL, '4', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(23, 'Derrick Bins', 'cheyanne.heidenreich@brekke.info', '09123456789', '3124 Brown Viaduct Apt. 587\nRobertaside, VA 83160', NULL, '1', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(24, 'Tanya Stoltenberg I', 'nsteuber@rippin.info', '09123456789', '7135 Cassidy Rapids Apt. 700\nEwellview, AL 24595-9176', NULL, '7', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(25, 'Rollin Waelchi', 'brandy.raynor@gmail.com', '09123456789', '6310 Roosevelt Street\nJefferyport, CA 01544', NULL, '7', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(26, 'Eriberto Stehr', 'camille.goldner@tremblay.com', '09123456789', '321 Kshlerin Ramp\nPort Delta, OR 20668', NULL, '4', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(27, 'Dr. Curt Waters II', 'quentin00@herzog.com', '09123456789', '45536 Upton Shores Suite 419\nNew Owenburgh, OR 25324', NULL, '1', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(28, 'Danial Rolfson', 'euna52@hotmail.com', '09123456789', '334 Candice Harbor Suite 080\nMozelleview, ME 71765', NULL, '4', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(29, 'Destiny Toy', 'koepp.brock@nikolaus.net', '09123456789', '829 Kassulke Village\nHickleport, MT 31491', NULL, '4', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(30, 'Maudie Quigley', 'lauryn11@legros.com', '09123456789', '1259 Gusikowski Stravenue\nWest Isaichester, NV 10286-1458', NULL, '1', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(31, 'Prof. Adrian Weber DDS', 'maurice.hayes@gaylord.com', '09123456789', '76107 Katelin Island Suite 549\nPort Jimmieville, HI 08410', NULL, '10', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(32, 'Hiram Legros Jr.', 'feest.eileen@buckridge.com', '09123456789', '79755 Aryanna Square Suite 966\nNew Tommie, NH 68055-1260', NULL, '1', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(33, 'Albin Senger', 'vhegmann@blanda.com', '09123456789', '205 Vandervort Loop Suite 533\nNorth Diamondbury, TX 20190', NULL, '1', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(34, 'Melyna Jacobi', 'lori38@runte.com', '09123456789', '577 Zetta Court\nHiltonberg, DC 86289', NULL, '10', 1, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(35, 'Bobby Padberg', 'angelo.lebsack@hotmail.com', '09123456789', '608 Darren Field Apt. 005\nLake Colten, CT 90255-2394', NULL, '4', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(36, 'Tobin Balistreri', 'shanahan.annabell@marks.biz', '09123456789', '76940 Rebeka Trafficway Apt. 580\nDarronside, NC 44800', NULL, '6', 3, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(37, 'Dr. Eloisa Reynolds', 'murphy.eusebio@ankunding.com', '09123456789', '301 Pouros Corners Suite 490\nLake Adriannaton, AK 02756', NULL, '9', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(38, 'Raven Hammes', 'xrenner@will.com', '09123456789', '1750 Zachery Road\nFloydfurt, ID 70925-9826', NULL, '5', 2, NULL, NULL, '2022-06-09 02:43:56', '2022-06-09 02:43:56'),
(39, 'Adrien Franecki', 'brittany.little@kozey.com', '09123456789', '3506 Julianne Plains\nShieldsstad, MI 48250-7616', NULL, '9', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(40, 'Miss Luisa Kunze MD', 'blick.blaise@bahringer.com', '09123456789', '45060 Ratke Islands\nKesslermouth, IN 50553', NULL, '8', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(41, 'Alvina Crooks I', 'ron.pacocha@yahoo.com', '09123456789', '137 Ortiz Drives Apt. 049\nPadbergberg, FL 53155', NULL, '10', 2, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(42, 'Lue Marquardt II', 'wyman.mattie@balistreri.com', '09123456789', '39274 Leannon Courts Apt. 752\nErnserborough, NV 92576-7993', NULL, '6', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(43, 'Antonetta Jerde V', 'harold.konopelski@skiles.com', '09123456789', '3924 Volkman Knoll\nSouth Bud, NJ 77328', NULL, '1', 2, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(44, 'Miss Esmeralda Zboncak PhD', 'devyn.wolff@yahoo.com', '09123456789', '8216 Donnelly Orchard\nBoscoville, DE 96464', NULL, '7', 3, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(45, 'Naomi Williamson PhD', 'judson18@johnston.com', '09123456789', '124 Janie Springs Suite 805\nNorth Merleberg, LA 62563', NULL, '1', 3, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(46, 'Eryn Gaylord', 'waylon.gerlach@yahoo.com', '09123456789', '4477 Wolf Spring Apt. 434\nBoscoborough, WA 32378-8459', NULL, '1', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(47, 'Domenick Keeling', 'kuphal.rosanna@yahoo.com', '09123456789', '5404 Dan Underpass\nCraigfort, NH 63395-6474', NULL, '9', 3, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(48, 'Fausto Waters DVM', 'ignacio.pfannerstill@yahoo.com', '09123456789', '78016 Powlowski Mountains Apt. 322\nEast Caleb, OR 00166', NULL, '8', 2, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(49, 'Joanne Mayert', 'nhansen@stanton.biz', '09123456789', '4337 Chesley Keys\nShieldsstad, LA 30912', NULL, '7', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57'),
(50, 'Lilla Howe', 'emanuel99@wisozk.biz', '09123456789', '390 Blanda Hollow Apt. 073\nEast Chloeland, MT 69445-9646', NULL, '6', 1, NULL, NULL, '2022-06-09 02:43:57', '2022-06-09 02:43:57');

-- --------------------------------------------------------

--
-- Table structure for table `table_management`
--

CREATE TABLE `table_management` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_seats` int(11) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_level_id` bigint(20) UNSIGNED NOT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_updated_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_expiration_date` timestamp NULL DEFAULT NULL,
  `first_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `email_updated_at` timestamp NULL DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_updated_at` timestamp NULL DEFAULT NULL,
  `password_expiration_date` timestamp NULL DEFAULT NULL,
  `old_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `temporary_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` enum('1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_active_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_level_id`, `profile_image`, `profile_image_updated_at`, `profile_image_expiration_date`, `first_name`, `last_name`, `username`, `contact_number`, `email`, `email_verified_at`, `email_updated_at`, `password`, `password_updated_at`, `password_expiration_date`, `old_password`, `temporary_password`, `address`, `account_status`, `ip`, `device`, `last_active_at`, `remember_token`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, NULL, NULL, NULL, 'eyJpdiI6Ilg0N2g4eG9tNy9oQ1NwanZlZy95ZEE9PSIsInZhbHVlIjoidnc4Nzg5NFRURkg4c3BFVU1heFdkQT09IiwibWFjIjoiMTAyNTY1OTViNTQ5ZDQyMWFkM2ZlNjBmMWRjNDA0N2M2NzgxNDhlZGRhMmNlYzkzNTFjNjcxNTIyZjE2MTM2MSIsInRhZyI6IiJ9', 'eyJpdiI6ImZRZU1VNm9IUmIxNG9uNk81Znl6dVE9PSIsInZhbHVlIjoiRVdSYnpXWWRQNEI2Zlh3bEZFRytPZz09IiwibWFjIjoiMGU5ZTk2NWMyODljMzIwMGUyZDY3ZDlkODVmYWY1MTNmYzBkMDU2NTAwOGY0MDIzY2Q1MGJiZmMzZTJjN2EyMSIsInRhZyI6IiJ9', 'robert', 'eyJpdiI6IlhpWnIyWnRVa1dmbEY5dEdpWHVkREE9PSIsInZhbHVlIjoiUUZpNi9JVHF0ODloVnVZclJ1Ynk1Zz09IiwibWFjIjoiMjJjZDdjODMwYjk5OTg0YWU0MjUwOWEzMDQ2MGEyMDA4NmYyYTllNGVhYjQ1M2M2Y2RiZWY5ODIzMjdkNmUwNCIsInRhZyI6IiJ9', 'moralesso152842@gmail.com', NULL, NULL, '$2y$10$ag3bfC3H8g8AwDOS2zE0BOcEMCf58hhmNYItmrw97Dy6WotunpgSu', NULL, NULL, NULL, NULL, 'Northern Samar', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-06-09 02:43:54', '2022-06-09 02:43:54', NULL),
(2, 1, NULL, NULL, NULL, 'eyJpdiI6IjBUSWcxcHJoQzZVL21YTjNwWGlhZ3c9PSIsInZhbHVlIjoibjYvNU9oZ0p3aTNBTkdxZUxoVU9BUT09IiwibWFjIjoiZDY2NmE3NzZhZDYwNGFiOTQ3Y2ZmZGRiYmI5NjhkYzExMmRhNzQ0MWEzY2MzMzNjMTYwMThkZDJmMGFlNjU4OCIsInRhZyI6IiJ9', 'eyJpdiI6IjFYcnVvb0xiSEJOaXQwUkdGOUpZdWc9PSIsInZhbHVlIjoiaEMxRG5vejFaZk9vNXJVNVJUNktBUT09IiwibWFjIjoiNmZhNDBhZjZjNDAwODNjN2ExMjI4MWZmZjNlOTAyMDdmNGMzMWUzNjJlODk2MjFlZTA4Y2ViZWQ2M2ZiMzU3YiIsInRhZyI6IiJ9', 'user', 'eyJpdiI6InlwN2QvQ1MwSTNtNmp1UnZxeWxQTkE9PSIsInZhbHVlIjoibFE5MkVVaVdBdXNnR1BkNXZwMmFLUT09IiwibWFjIjoiMmVhMWQzYmRmYzE3ZjA5YjE1ODE1ZTRjODZlN2U3ZDE1ZWJlY2ZjYjQ3OTUzMDQ3YmI1ZTI2ODBjZGU4Mzg2MiIsInRhZyI6IiJ9', 'test@gmail.com', NULL, NULL, '$2y$10$JpJg3dxu41gXxQ4Pdy1.OeuDkxBcTsJ7NL24PPOZB9i5y74OKtT7G', NULL, NULL, NULL, NULL, 'Philippines', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-06-09 02:43:55', '2022-06-09 02:43:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_browser_sessions`
--

CREATE TABLE `user_browser_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `device_family` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plaform_family` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plaform_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac_address` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_levels`
--

CREATE TABLE `user_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modules` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'parent navigation IDs',
  `sub_modules` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'child navigation IDs',
  `create` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_trail_logs`
--
ALTER TABLE `audit_trail_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigations`
--
ALTER TABLE `navigations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_management`
--
ALTER TABLE `table_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_contact_number_unique` (`contact_number`) USING HASH,
  ADD KEY `user_level_id` (`user_level_id`);

--
-- Indexes for table `user_browser_sessions`
--
ALTER TABLE `user_browser_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_levels`
--
ALTER TABLE `user_levels`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_trail_logs`
--
ALTER TABLE `audit_trail_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `navigations`
--
ALTER TABLE `navigations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `table_management`
--
ALTER TABLE `table_management`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_browser_sessions`
--
ALTER TABLE `user_browser_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_levels`
--
ALTER TABLE `user_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
